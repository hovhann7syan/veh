import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

// Supabase с service role — для записи заказов (обходит RLS)
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(req: NextRequest) {
  const body      = await req.text();
  const signature = req.headers.get("stripe-signature")!;

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    console.error("Webhook signature failed:", err);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  // Обрабатываем успешную оплату
  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const userId  = session.metadata?.userId;

    if (!userId || userId === "guest") {
      return NextResponse.json({ received: true });
    }

    // Получаем детали сессии с товарами
    const fullSession = await stripe.checkout.sessions.retrieve(session.id, {
      expand: ["line_items"],
    });

    const lineItems = fullSession.line_items?.data || [];

    // Создаём заказ в Supabase
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert({
        user_id:            userId,
        status:             "paid",
        total:              (session.amount_total || 0) / 100,
        payment_method:     "stripe",
        stripe_payment_id:  session.payment_intent as string,
        shipping_address: (session as any).shipping_details ?? null,      })
      .select()
      .single();

    if (orderError || !order) {
      console.error("Order creation failed:", orderError);
      return NextResponse.json({ error: "Order failed" }, { status: 500 });
    }

    // Добавляем товары в order_items
    const orderItems = lineItems.map((item) => ({
      order_id:     order.id,
      product_name: item.description || "Product",
      price:        (item.price?.unit_amount || 0) / 100,
      quantity:     item.quantity || 1,
      size:         "—",
    }));

    await supabase.from("order_items").insert(orderItems);
  }

  return NextResponse.json({ received: true });
}